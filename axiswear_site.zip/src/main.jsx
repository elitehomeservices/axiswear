
import React from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import AxiswearSite from './AxiswearSite'

createRoot(document.getElementById('root')).render(<AxiswearSite />)

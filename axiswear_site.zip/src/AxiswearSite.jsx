import React, { useState } from "react";

const GOLD = "#C9A34A"; // luxury gold accent
const BG = "#0b0b0b"; // deep black background

const PRODUCTS = [
  {
    id: "cap-01",
    name: "Axiswear Heritage Cap",
    category: "Caps",
    price: 120,
    short: "Matte black cap with gold embroidered A-crest.",
    colors: ["Matte Black"],
    hero: "cap",
    img: "/assets/cap.png"
  },
  {
    id: "shoe-01",
    name: "Axiswear Luxe Sneaker",
    category: "Shoes",
    price: 620,
    short: "Full-grain black leather, gold hardware, embossed heel logo.",
    colors: ["Matte Black"],
    hero: "shoe",
    img: "/assets/shoe.png"
  },
  {
    id: "shirt-01",
    name: "Axiswear Signature Tee",
    category: "Shirts",
    price: 150,
    short: "Heavyweight black cotton, small gold A on chest.",
    colors: ["Matte Black"],
    hero: "shirt",
    img: "/assets/shirt.png"
  },
];

function Logo({ size = 40 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width="64" height="64" rx="8" fill="transparent" />
      <path d="M32 10 L48 46 H40 L32 28 L24 46 H16 L32 10 Z" fill={GOLD} />
    </svg>
  );
}

function Hero({ onShopClick }) {
  return (
    <header className="relative flex items-center justify-center h-screen bg-black text-white">
      <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, rgba(0,0,0,0.45), rgba(0,0,0,0.8))` }} />
      <div className="z-10 max-w-6xl px-6 text-center">
        <div className="flex items-center justify-center gap-3 mb-8">
          <Logo size={48} />
          <span className="text-sm tracking-wide" style={{ color: GOLD }}>AXISWEAR</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-semibold leading-tight">
          Style in
          <br />
          <span className="text-transparent bg-clip-text" style={{ backgroundImage: `linear-gradient(90deg, ${GOLD}, #ffd57a)` }}>Every Direction</span>
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-gray-300">Luxury-crafted apparel that moves between street, wear, and performance — all anchored in a single vision.</p>
        <div className="mt-8 flex items-center justify-center gap-4">
          <button
            onClick={() => onShopClick()}
            className="px-6 py-3 rounded-md text-black font-medium"
            style={{ background: GOLD }}
          >
            Shop Collection
          </button>
          <a href="#about" className="px-6 py-3 rounded-md border border-gray-700 text-gray-300">Our Craft</a>
        </div>
      </div>
    </header>
  );
}

function Nav({ onOpenCart }) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Logo size={30} />
            <span className="text-sm font-semibold" style={{ color: GOLD }}>AXISWEAR</span>
          </div>
        </div>
        <div className="flex items-center gap-6 text-sm text-gray-300">
          <a href="#collections" className="hover:text-white">Collections</a>
          <a href="#shop" className="hover:text-white">Shop</a>
          <a href="#about" className="hover:text-white">About</a>
          <button onClick={onOpenCart} className="px-3 py-1 border border-gray-700 rounded">Bag</button>
        </div>
      </div>
    </nav>
  );
}

function ProductCard({ product, onOpen }) {
  return (
    <div className="group bg-black border border-gray-800 p-6 rounded-2xl flex flex-col items-start gap-4">
      <div className="rounded-xl overflow-hidden w-full flex items-center justify-center" style={{ background: '#070707' }}>
        <img src={product.img} alt={product.name} className="object-contain w-full h-56" />
      </div>
      <div className="flex items-center justify-between w-full">
        <div>
          <h3 className="text-white text-lg font-medium">{product.name}</h3>
          <p className="text-gray-400 text-sm mt-1">{product.short}</p>
        </div>
        <div className="text-right">
          <div className="text-white font-semibold">${product.price}</div>
          <div className="text-gray-400 text-xs">{product.category}</div>
        </div>
      </div>
      <div className="w-full flex items-center gap-3">
        <button onClick={() => onOpen(product)} className="px-4 py-2 rounded-md" style={{ background: GOLD }}>Quick view</button>
        <button className="px-4 py-2 rounded-md border border-gray-700 text-gray-300">Add to bag</button>
      </div>
    </div>
  );
}

function ShopGrid({ onOpen }) {
  return (
    <section id="shop" className="py-20">
      <div className="max-w-6xl mx-auto px-6">
        <h2 className="text-3xl text-white font-semibold mb-8">Shop</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PRODUCTS.map((p) => (
            <ProductCard key={p.id} product={p} onOpen={onOpen} />
          ))}
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="py-20 bg-black">
      <div className="max-w-5xl mx-auto px-6 text-gray-300">
        <h3 className="text-2xl text-white font-semibold mb-4">Our Craft</h3>
        <p className="leading-relaxed">Axiswear blends sartorial craft with technical performance. Materials are sourced from vetted ateliers and finished with gold-detailed hardware to ensure each piece reads as both versatile and luxurious. Every stitch is considered — our garments age beautifully and are built to last.</p>
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-900 p-6 rounded-lg">
            <h4 className="text-white font-medium">Materials</h4>
            <p className="text-gray-400 text-sm mt-2">Full-grain leather, heavy-weight organic cotton, and tailored wool blends.</p>
          </div>
          <div className="bg-gray-900 p-6 rounded-lg">
            <h4 className="text-white font-medium">Production</h4>
            <p className="text-gray-400 text-sm mt-2">Limited small-batch runs with a focus on ethical manufacturing.</p>
          </div>
          <div className="bg-gray-900 p-6 rounded-lg">
            <h4 className="text-white font-medium">Sustainability</h4>
            <p className="text-gray-400 text-sm mt-2">Durable designs reduce waste — we offer repair guides and limited reworks.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="py-10 text-gray-400 border-t border-gray-900">
      <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Logo size={28} />
          <div>
            <div className="text-white font-semibold">Axiswear</div>
            <div className="text-xs">Style in Every Direction</div>
          </div>
        </div>
        <div className="text-sm">© {new Date().getFullYear()} Axiswear — All rights reserved.</div>
      </div>
    </footer>
  );
}

export default function AxiswearSite() {
  const [modalProduct, setModalProduct] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <div style={{ background: BG, color: "#fff", minHeight: "100vh" }}>
      <Nav onOpenCart={() => setCartOpen(true)} />
      <main>
        <Hero onShopClick={() => { document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' }); }} />

        <section id="collections" className="py-20">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-black border border-gray-800 rounded-2xl p-10 flex flex-col items-start gap-6">
                <h3 className="text-xl font-semibold">Urban Core</h3>
                <p className="text-gray-400">Street-driven essentials with premium finishes: oversized fits with gold embroidery.</p>
                <div className="mt-4 w-full">
                  <div className="rounded-lg overflow-hidden"><img src="/assets/cap.png" alt="cap" /></div>
                </div>
              </div>
              <div className="bg-black border border-gray-800 rounded-2xl p-10 flex flex-col items-start gap-6">
                <h3 className="text-xl font-semibold">Elemental Line</h3>
                <p className="text-gray-400">Tailored, minimal, and impeccably finished. Neutral silhouettes elevated by gold hardware.</p>
                <div className="mt-4 w-full"><img src="/assets/shirt.png" alt="shirt" /></div>
              </div>
              <div className="bg-black border border-gray-800 rounded-2xl p-10 flex flex-col items-start gap-6">
                <h3 className="text-xl font-semibold">Performance Series</h3>
                <p className="text-gray-400">Technical fabrics, considered cuts — designed to move without sacrificing luxury aesthetics.</p>
                <div className="mt-4 w-full"><img src="/assets/shoe.png" alt="shoe" /></div>
              </div>
            </div>
          </div>
        </section>

        <ShopGrid onOpen={(p) => setModalProduct(p)} />
        <About />
      </main>

      <Footer />

      {modalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/70" onClick={() => setModalProduct(null)} />
          <div className="relative max-w-4xl w-full mx-6 bg-[#070707] border border-gray-800 rounded-2xl p-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex items-center justify-center">
                <img src={modalProduct.img} alt={modalProduct.name} className="object-contain w-full h-72" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <Logo size={36} />
                  <div>
                    <h3 className="text-2xl font-semibold">{modalProduct.name}</h3>
                    <div className="text-gray-400">{modalProduct.category}</div>
                  </div>
                </div>
                <p className="text-gray-300 mb-4">{modalProduct.short}</p>
                <div className="text-2xl font-semibold text-white mb-6">${modalProduct.price}</div>
                <div className="flex items-center gap-3">
                  <button className="px-6 py-3 rounded-md" style={{ background: GOLD }}>Add to bag</button>
                  <button onClick={() => setModalProduct(null)} className="px-6 py-3 rounded-md border border-gray-700 text-gray-300">Close</button>
                </div>
                <div className="mt-6 text-sm text-gray-500">Free returns within 14 days. Limited small-batch runs — some styles will not be restocked.</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {cartOpen && (
        <div className="fixed inset-0 z-40 flex items-end md:items-center justify-end">
          <div className="absolute inset-0 bg-black/60" onClick={() => setCartOpen(false)} />
          <div className="relative w-full md:w-96 bg-[#080808] p-6 border-l border-gray-900">
            <div className="flex items-center justify-between mb-6">
              <div className="text-lg font-semibold">Your Bag</div>
              <button onClick={() => setCartOpen(false)} className="text-gray-400">Close</button>
            </div>
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-white">Axiswear Signature Tee</div>
                  <div className="text-gray-400 text-sm">1 × $150</div>
                </div>
                <div className="text-white font-semibold">$150</div>
              </div>
            </div>
            <div className="mt-6">
              <div className="flex items-center justify-between text-gray-400 mb-4">
                <div>Subtotal</div>
                <div className="text-white font-semibold">$150</div>
              </div>
              <button className="w-full py-3 rounded-md" style={{ background: GOLD }}>Checkout</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

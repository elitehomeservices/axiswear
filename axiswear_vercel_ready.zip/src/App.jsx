import React from 'react'

export default function App() {
  return (
    <div className="bg-black min-h-screen">
      {/* Navbar */}
      <header className="flex justify-between items-center px-8 py-4 border-b border-gold sticky top-0 bg-black/80 backdrop-blur z-50">
        <h1 className="text-2xl md:text-3xl font-bold text-gold tracking-wide">AXISWEAR</h1>
        <nav className="space-x-6 text-gold text-sm md:text-base">
          <a href="#shop" className="hover:text-white">Shop</a>
          <a href="#about" className="hover:text-white">About</a>
          <a href="#contact" className="hover:text-white">Contact</a>
        </nav>
      </header>

      {/* Hero */}
      <section
        className="relative flex items-center justify-center h-[85vh] bg-neutral-950"
      >
        <img src="/assets/hero.svg" alt="Axiswear hero" className="absolute inset-0 w-full h-full object-cover" />
        <div className="relative z-10 bg-black/50 p-8 rounded-2xl border border-gold text-center mx-6">
          <h2 className="text-4xl md:text-6xl font-bold mb-4 text-gold">Style in Every Direction</h2>
          <p className="text-gray-200 mb-6 max-w-2xl">
            Luxury black & gold streetwear — refined, minimal, and built to last.
          </p>
          <a href="#shop" className="px-6 py-3 bg-gold text-black font-semibold rounded hover:bg-white transition">
            Explore Collection
          </a>
        </div>
      </section>

      {/* Shop Section */}
      <section id="shop" className="px-6 md:px-10 py-16">
        <h3 className="text-3xl md:text-4xl font-semibold mb-10 text-center text-gold">Our Collection</h3>
        <div className="grid md:grid-cols-3 gap-8 md:gap-12">
          {[
            { name: 'Black & Gold Cap', img: '/assets/cap.svg', price: '$120' },
            { name: 'Luxury Sneakers', img: '/assets/shoes.svg', price: '$620' },
            { name: 'Premium Tee', img: '/assets/shirt.svg', price: '$150' },
          ].map((p) => (
            <div key={p.name} className="bg-neutral-900 rounded-2xl overflow-hidden shadow-lg border border-gold">
              <img src={p.img} alt={p.name} className="w-full h-72 object-contain bg-black" />
              <div className="p-6">
                <h4 className="text-xl font-semibold text-gold">{p.name}</h4>
                <p className="text-white mt-2">{p.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* About */}
      <section id="about" className="px-6 md:px-10 py-16 bg-neutral-900 border-t border-gold/40">
        <h3 className="text-3xl md:text-4xl font-semibold mb-6 text-gold">Our Story</h3>
        <p className="text-gray-200 max-w-3xl leading-relaxed">
          Axiswear blends sartorial craft with technical performance. Materials are sourced from vetted ateliers and finished with gold-detailed hardware to ensure each piece reads as both versatile and luxurious.
        </p>
        <div className="grid md:grid-cols-3 gap-6 mt-10">
          <div className="bg-black p-6 rounded-xl border border-neutral-800">
            <div className="text-gold font-medium mb-2">Materials</div>
            <div className="text-gray-300 text-sm">Full-grain leather, heavy-weight organic cotton, tailored wool blends.</div>
          </div>
          <div className="bg-black p-6 rounded-xl border border-neutral-800">
            <div className="text-gold font-medium mb-2">Production</div>
            <div className="text-gray-300 text-sm">Limited small-batch runs with ethical manufacturing partners.</div>
          </div>
          <div className="bg-black p-6 rounded-xl border border-neutral-800">
            <div className="text-gold font-medium mb-2">Sustainability</div>
            <div className="text-gray-300 text-sm">Durable designs that age beautifully and reduce waste.</div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="px-6 md:px-10 py-16">
        <h3 className="text-3xl md:text-4xl font-semibold mb-6 text-gold">Get in Touch</h3>
        <form className="max-w-xl space-y-4">
          <input type="text" placeholder="Your Name" className="w-full p-3 rounded bg-neutral-800 text-white border border-gold" />
          <input type="email" placeholder="Your Email" className="w-full p-3 rounded bg-neutral-800 text-white border border-gold" />
          <textarea placeholder="Your Message" rows="4" className="w-full p-3 rounded bg-neutral-800 text-white border border-gold"></textarea>
          <button type="submit" className="px-6 py-3 bg-gold text-black font-semibold rounded hover:bg-white transition">Send</button>
        </form>
      </section>

      {/* Footer */}
      <footer className="text-center py-8 border-t border-gold text-gray-300">
        © {new Date().getFullYear()} AXISWEAR. All rights reserved.
      </footer>
    </div>
  )
}
